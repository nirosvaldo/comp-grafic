<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
        <div class="fiotao">
            <a href="form3.html"><button>voltar</button></a>
            <br>
            <img src="img/individuo.png" alt="" class="cab_img">
            <h1 class="cab_tit">individeo gamer
            </h1>
            <P class="cab_slogan">bem vindo
            </P>
            </div>
        </header>
        <div id="div2h"><br>
            <table id="tab2">
                <tr id="tr2">
                    <td id="demoimg">
            <img src="img/teclado.png" id="demo">
        </td>
        <td id="info">
            <Div id="name">
                <br>
                <font size="5px">teclado</font>
            </Div>
            <Div id="opcoes">
                <div id="itens">
                tipo<select>
                    <option>
                        Gamer
                    </option>
                    <option>
                        comum
                    </option>
                    <option>
                        mecanico
                    </option>
                </select></div>
            </Div>
            </td>
        
    </tr>
    </table> 
<div id="div3">
    |Luis Gabriel C. Ph.|n°14|<br>|Arthur Bertolini|n°4|<br>|Adrian Phellipe S Rhoden|n°2|<br>|3° dev. sist.|colegio prof. victorio|<font color="gray"> por favor me ajuda</font>
</div>
</body>
</html>