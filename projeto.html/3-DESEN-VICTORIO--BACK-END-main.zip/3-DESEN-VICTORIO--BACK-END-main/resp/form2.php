<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="style.css">
<body>
    <header class="cabecalho">
        <div class="fiotao">
            <a href="index.html">voltar</a>
            <img src="img/individuo.png" alt="" class="cab_img">
            <h1 class="cab_tit">individeo gamer
            </h1>
            <P class="cab_slogan">bem vindo
            </P>
            </div>
        </header>
    <div id="div2f"><br>
    <fieldset id="borda"><br>
    <legend id="title">antes de comprar,<br>primeiro<br><b>VAMOS LOGAR</b></legend>
    <label>insira seu email</label><br>
    <input type="text" placeholder="seu email"><br>
    <label>insira sua senha</label><br>
    <input type="text" placeholder="sua senha"><br>
    <label>tudo pronto? então envie para gente</label><br>
    <a href="form3.html"><button>enviar</button></a><br>
    </fieldset><br>
    </div>
    <div id="div3">
        |Luis Gabriel C. Ph.|n°14|<br>|Arthur Bertolini|n°4|<br>|Adrian Phellipe S Rhoden|n°2|<br>|3° dev. sist.|colegio prof. victorio|<font color="gray"> por favor me ajuda</font>
        </div>
</body>
</html>