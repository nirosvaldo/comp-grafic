<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
    <div class="fiotao">
        <img src="img/individuo.png" alt="" class="cab_img">
        <h1 class="cab_tit">INDIVIDEO GAMER </h1>
        <P class="cab_slogan">bem vindo
        </P>
        </div>
    </header>
    <table id="tab">
        <tr id="tr">
            <td>
            <div id="div2">
                <a href=form.html>
                    <div id="div2a" >
                    <P><br>novo por aqui?<br>clique aqui para cadastrar<br></P>
                </div> </a>
            
                <a href=form2.html>
                    <div id="div2b" >
                    <p><br>já possui conta né?<br>clique aqui para logar<br></p>
                </div></a>
            
                <a href=form3.html>
                    <div id="div2c" >
                        <p><br>quer entrar como anonimo?<br>clique aqui para apenas entrar<br></p>
                    </div>
                </a>
            </div>
        </td>
        <td>
            <div id="divcapi">
                <img src="img/caipivara.png" id="capi">
            </div>
        </td>
            
    </table>  
    <div id="div3">
        |Luis Gabriel C. Ph.|n°14|<br>|Arthur Bertolini|n°4|<br>|Adrian Phellipe S Rhoden|n°2|<br>|3° dev. sist.|colegio prof. victorio|<font color="gray"> por favor me ajuda</font>
        </div>

</body>
</html>