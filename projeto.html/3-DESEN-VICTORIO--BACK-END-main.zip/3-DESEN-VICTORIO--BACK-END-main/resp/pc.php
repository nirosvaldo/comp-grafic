<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
        <div class="fiotao">
            <a href="form3.html"><button>voltar</button></a>
            <br>
            <img src="img/individuo.png" alt="" class="cab_img">
            <h1 class="cab_tit">individio gamer
            </h1>
            <P class="cab_slogan">bem vindo
            </P>
            </div>
        </header>
        <div id="div2h"><br>
            <table id="tab3">
                <tr id="tr2">
                    <td id="demoimg">
            <img src="img/pc.jpeg" id="demo">
        </td>
        <td id="info">
            <Div id="name">
                <br>
                <font size="5px">Pc</font>
            </Div>
            <Div id="opcoes">
                <div id="itens">
                gabinete <select>
                    <option>
                        thermaltake
                    </option>
                    <option>
                        ASUS
                    </option>
                    <option>
                        cooler master
                    </option>
                    <option>
                        corsair    
                    </option>
                    <option>
                        PCYES       
                    </option>
                    </select><br><br>
                <i>fans</i><select>
                    <option>
                        PCYES
                    </option>
                    <option>
                        Brazil PC
                    </option>
                    <option>
                        gigabyte
                    </option>
                    </select></div><br>
                <div id="itens">
                placa de video <select>
                                <option>
                                    nvidia series rtx10
                                    ou
                                    amd  series RX500
                                </option>
                                <option>
                                    nvidia series rtx20
                                    ou
                                    amd series RX500
                                </option>
                                <option>
                                    nvidia rtx30
                                    ou 
                                    amd series rx6000
                                </option>
                                <option>
                                    nvidia rtx40
                                          ou
                                       amd seris rx7000
                                </option>
                    </select></div><br>
                <div id="itens">
                processador <select>
                    <option>
                        intel core i3
                     </option>
                     <option>
                        intel core i5
                     </option>
                    <option>
                        intel core i7
                     </option>
                     <option>
                       intel core i9
                    </option>
                    </select></div><br>
                <div id="itens">
                memoria ram <select>
                    <option>
                        kfb DDR4
                    </option>
                    <option>
                        kfb DDR5
                    </option>
                    <option>
                        
                    </option>
                    </select></div><br>
                <div id="itens">
                armazenamento <select>
                    <option>
                        SSD NVME
                    </option>
                    <option>
                        SSD SATA
                    </option>
                    </select></div><br>
                <div id="itens">
                fonte <select>
                    <option>
                       corsair HX1000i 
                    </option>
                    <option>
                        corsair HX500i 
                     </option>
                     <option>
                        corsair CV650
                     </option>
                    </select></div><br>
            </Div>
            </td>
        </tr>
    </table>
</div> 
<div id="div3">
    |Luis Gabriel C. Ph.|n°14|<br>|Arthur Bertolini|n°4|<br>|Adrian Phellipe S Rhoden|n°2|<br>|3° dev. sist.|colegio prof. victorio|<font color="gray"> por favor me ajuda</font>
</div>
</body>
</html>