<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
@import url(styles/estilooooooo)
<body>
    <script>
   alert("0l@ Mund0")
   var nome = prompt("qual o seu nome?")
   var idade = prompt("qual o sua idade?")
   alert("0la "+(nome)+" com "+(idade)+" anos")
    </script><br>
    
    
</body>
</html>