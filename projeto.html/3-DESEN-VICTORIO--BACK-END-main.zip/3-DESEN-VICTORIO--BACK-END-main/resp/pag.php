<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="cabecalho">
        <div class="fiotao">
            <a href="form3.html"><button>voltar</button></a>
            <br>
            <img src="img/individuo.png" alt="" class="cab_img">
            <h1 class="cab_tit">individeo gamer
            </h1>
            <P class="cab_slogan">bem vindo
            </P>
            </div>
        </header>
        <div id="div2f"><br>
            <fieldset id="borda">
            <legend id="title">agora que já escolheu seus produtos<br><b>vamos pagar</b></legend>
        <label>como vai pagar?</label><br>
        <select>
            <option>
                credito
            </option>
            <option>
                debito
            </option>
            <option>
                pix
            </option>
            <option>
                a vista
            </option>
            <option>
                esmeraldas
            </option>   
        </select><br>
        <label>coloque o número do cartão</label><br>
        <input type="text" placeholder="numero do cartão"><br>        
<label>coloque a senha do cartão</label><br>
<input type="text" placeholder="senha"><br>
<label>coloque o cpf</label> e <label>coloque o cvc</label><br>
<input type="text" placeholder="cpf"> 
<input type="text" placeholder="cvc"><br>
<label>coloque a validade</label><br>
<input type="datetime" placeholder="dd/mm"><br>
<label>pagamento feito?<br> então vamos retirar sua nota</label><br>
<a href="nota.html"><button>retirar</button></a><br>

</fieldset> 
   <br> 
</div>
<div id="div3">
    |Luis Gabriel C. Ph.|n°14|<br>|Arthur Bertolini|n°4|<br>|Adrian Phellipe S Rhoden|n°2|<br>|3° dev. sist.|colegio prof. victorio|<font color="gray"> por favor me ajuda</font>
</div>
</body>
</html>