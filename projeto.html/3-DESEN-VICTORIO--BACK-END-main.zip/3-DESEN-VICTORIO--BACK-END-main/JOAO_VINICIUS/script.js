function iniciarJogo() {
    alert('Jogo iniciado!'); // Substitua por lógica real do jogo
}

// Lógica do jogo seria implementada aqui
